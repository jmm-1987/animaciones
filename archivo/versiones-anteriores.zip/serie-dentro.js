(()=>{
const stage=document.querySelector('body[data-serie="dentro"] #stage');if(!stage)return;
const marks=window.STORY_CONFIG.marks,buttons=[...stage.querySelectorAll('[data-slide-step]')],count=document.querySelector('#inside-slide-count');
let previous=Number(stage.dataset.phase)||0;
function update(){const phase=Number(stage.dataset.phase)||0;stage.dataset.slideDirection=phase<previous?'back':'forward';previous=phase;count.textContent=(phase+1)+' / '+(marks.length-1);buttons.forEach(b=>b.disabled=Number(b.dataset.slideStep)<0?phase===0:phase===marks.length-2);}
function step(delta){const phase=Math.max(0,Math.min(marks.length-2,(Number(stage.dataset.phase)||0)+delta));const seek=document.querySelector('#seek');seek.value=marks[phase];seek.dispatchEvent(new Event('input',{bubbles:true}));}
buttons.forEach(b=>b.addEventListener('click',()=>step(Number(b.dataset.slideStep))));
new MutationObserver(update).observe(stage,{attributes:true,attributeFilter:['data-phase']});
document.addEventListener('keydown',e=>{if(/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)||document.activeElement.isContentEditable)return;if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();step(e.key==='ArrowRight'?1:-1);}});
let origin=null;
stage.addEventListener('pointerdown',e=>{if(e.target.closest('button,a,input')||!e.isPrimary)return;origin={x:e.clientX,y:e.clientY};});
stage.addEventListener('pointerup',e=>{if(!origin)return;const dx=e.clientX-origin.x,dy=e.clientY-origin.y;origin=null;if(Math.abs(dx)>45&&Math.abs(dx)>Math.abs(dy)*1.5)step(dx<0?1:-1);});
stage.addEventListener('pointercancel',()=>origin=null);stage.addEventListener('pointerleave',()=>origin=null);update();
})();
