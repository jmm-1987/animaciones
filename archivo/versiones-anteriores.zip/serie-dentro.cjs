const fs=require('fs');
const {createPage}=require('./historias.cjs');
const robot=require('./personajes-alternativos.cjs').find(s=>s.id==='robot').art;
const slugs=["primero-el-papel","el-caso-raro","un-boton-menos","conectar-con-cuidado","version-tras-version","tambien-en-el-movil"];
const episodes=require('./dentro-soluciones.cjs').map((e,i)=>({...e,slug:slugs[i]}));
const panel=require('./dentro-demostraciones.cjs');
for(const [i,e] of episodes.entries()){
 const file=`dentro-${String(i+1).padStart(2,'0')}-${e.slug}.html`;e.file=file;
 const narration=e.narration.map(text=>text.replace('JM2 en movimiento','Seguimos en movimiento').replace('Así entendemos JM2','Así entendemos nuestro trabajo').replace('JM2. Ideas','Ideas'));
 const story={file,audioKey:file,title:e.title,variant:'dentro',voice:false,timing:{duration:30,marks:[0,5,11,18,25,30]},copy:e.copy,shots:e.cards.map((pair,phase)=>panel(pair,phase,e)),narration};
 story.social={keyword:'DENTRO DE JM2',message:''};
 createPage('datos',{story});
 let html=fs.readFileSync(file,'utf8');
 const ending=`<section class="story-scene ending inside-ending" data-scene="4" aria-label="Dentro de JM2"><span>DENTRO DE JM2 · ${String(i+1).padStart(2,'0')} / 06</span><h2>${e.narration[4]}</h2><img class="ending-logo" src="logo.png" alt="JM2 Tech Studio"><p>Menos tareas repetidas. M?s tiempo para tu negocio.</p></section>`;
 html=html.replace(/<section[^>]*class="story-scene ending"[\s\S]*?<\/section>/,ending).replace('</head>','<link rel="stylesheet" href="serie-dentro.css"></head>').replace('data-montaje="integrado"','data-montaje="integrado" data-serie="dentro"');
 html=html.replace(/<nav class="version-switch"[\s\S]*?<\/nav>/,'<nav class="version-switch"><a href="index-dentro.html">← Los seis episodios de Dentro de JM2</a></nav>');
 html=html.replace('LOCUCIÓN · LISTA PARA PREPARAR EN CREATIFY','LOCUCIÓN · DENTRO DE JM2');
 html=html.replace('<nav class="scene-nav"','<div class="inside-slider-controls" aria-label="Diapositivas"><button type="button" data-slide-step="-1" aria-label="Diapositiva anterior">←</button><span id="inside-slide-count" aria-live="polite">1 / 5</span><button type="button" data-slide-step="1" aria-label="Diapositiva siguiente">→</button></div><nav class="scene-nav"');
 html=html.replace('</body>','<script src="serie-dentro.js"></script></body>');
 fs.writeFileSync(file,html);
}
const cards=episodes.map((e,i)=>`<a class="episode" href="${e.file}"><span>CUADERNO ${String(i+1).padStart(2,'0')} · 30 S</span><h2>${e.title}</h2><p>${e.desc}</p><b>Ver episodio →</b></a>`).join('');
fs.writeFileSync('index-dentro.html',`<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Dentro de JM2 · Ideas, personas y ganas</title><link rel="stylesheet" href="serie-dentro.css"></head><body class="inside-index"><main><header><img src="logo.png" alt="JM2 Tech Studio"><a href="index.html">← Biblioteca</a></header><section class="inside-hero"><div><span>DENTRO DE JM2 · NUEVA SERIE</span><h1>Tu trabajo.<br>Un poco<br><em>m?s f?cil.</em></h1><p>Lo que nos mueve: escuchar, compartir ideas y encontrarle otra vuelta a las cosas de cada día.</p></div><svg viewBox="0 0 420 340" role="img" aria-label="Robot de taller con el logo de JM2">${robot}</svg></section><section class="inside-grid" aria-label="Los seis episodios">${cards}</section><footer>JM2 Tech Studio · Mérida<br>Pequeñas historias sobre nuestra manera de ver el trabajo.</footer></main></body></html>`);
let index=fs.readFileSync('index.html','utf8').replace('Dentro de JM2 ? Ideas, pruebas y detalles','Dentro de JM2 ? Ideas, personas y ganas').replace('Seis historias sobre el proceso de construir, probar y mejorar.','Seis historias cotidianas para conocer un poco m?s a JM2.');
if(!index.includes('href="index-dentro.html"'))index=index.replace('<aside class="collection">','<aside class="collection"><div><h2>Dentro de JM2 · Ideas, personas y ganas</h2><p>Seis historias cotidianas para conocer un poco m?s a JM2.</p></div><a href="index-dentro.html">Ver la nueva serie →</a></aside><aside class="collection">');
fs.writeFileSync('index.html',index);
console.log('Dentro de JM2: seis episodios, índice y guiones generados.');
module.exports={episodes};
